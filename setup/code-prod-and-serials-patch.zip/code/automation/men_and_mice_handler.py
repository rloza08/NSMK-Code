#!/usr/bin/env python3
from api.men_and_mice import get_vlan_funnel

def update_funnel():
    get_vlan_funnel()

if __name__ == '__main__':
    pass
