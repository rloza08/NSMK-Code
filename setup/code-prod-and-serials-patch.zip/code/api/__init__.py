#!/usr/bin/env python3
"""Used only to keep pylint quiet"""