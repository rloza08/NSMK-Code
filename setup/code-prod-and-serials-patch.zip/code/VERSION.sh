#!/bin/bash
echo "### NSMK AUTOMATION VERSION: ##"
git describe --tags
echo "###############################"
